# 🛍️ Customer Segmentation & Recommendation System for Indian E-commerce

## Overview
A powerful, end-to-end system for customer segmentation and product recommendation tailored to Indian e-commerce platforms like Flipkart and Meesho.

### 🔧 Features
- Customer clustering using unsupervised ML (KMeans)
- Product embeddings using Hugging Face transformers
- Cosine similarity for item-based recommendations
- Streamlit frontend for interactive demos
- Deployable via ngrok from Google Colab

### 🛠️ Tech Stack
- Python, Pandas, Scikit-learn
- Hugging Face Transformers
- Streamlit for UI
- Google Colab + Pyngrok for deployment

### 📂 Structure
- `app.py`: Streamlit app code
- `dataframe.pkl`: Cleaned product dataset
- `similarity_matrix.pkl`: Precomputed similarity matrix
- `README.md`: Project documentation

