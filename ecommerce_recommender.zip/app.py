import streamlit as st
import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import joblib

# Load models and data
df = joblib.load("dataframe.pkl")
similarity_matrix = joblib.load("similarity_matrix.pkl")

def recommend_products(product_name, top_k=5):
    matches = df[df['product_name'].str.lower() == product_name.lower()]
    if matches.empty:
        st.error("❌ Product not found. Try another name.")
        st.write("Here are some examples:")
        st.write(df['product_name'].sample(5).to_list())
        return

    idx = matches.index[0]
    sim_scores = list(enumerate(similarity_matrix[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)[1:top_k+1]

    st.success(f"Top {top_k} products similar to '{product_name}':")
    for i, score in sim_scores:
        st.write(f"- {df.iloc[i]['product_name']} (Score: {score:.2f})")

st.title("🛍️ Indian E-Commerce Product Recommender")
product = st.text_input("Enter a product name:")
if st.button("Recommend"):
    recommend_products(product)
